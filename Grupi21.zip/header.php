<header>
			<div class="logo-container">
				<i class="fa fa-apple fa-2x fa-spin" style="color:white;"></i>
			</div>
			<nav>
				<ul class="nav-links">
					<li><a class="nav-link" href="index.php">iCloud Unlock</a></li>
					<li><a class="nav-link" href="sim.php">Network Check</a></li>
					<li><a class="nav-link" href="order.php">JailBreak</a></li>
					<li><a class="nav-link" href="policy.php">Privacy Policy</a></li>
					<li><a class="nav-link" href="aboutUs.php">About Us</a></li>
				</ul>
			</nav>
			
</header>