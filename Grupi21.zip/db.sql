create table kontakrinor(
	id1 int primary key auto_increment,
	firstname1 text not null,
	lastname1 text not null,
	email1 varchar(255) unique,
	mosha1 int
);

create table kontaktlirim(
	id2 int primary key auto_increment,
	firstname2 text not null,
	lastname2 text not null,
	email2 varchar(255) unique,
	mosha2 int
);

create table kontakturan(
	id3 int primary key auto_increment,
	firstname3 text not null,
	lastname3 text not null,
	email3 varchar(255) unique,
	mosha3 int
);

create table sherbimet(
	id int primary key auto_increment,
	imei bigint not null unique,
	lloji text not null,
	koha timestamp not null
);

create table ajaxi(
	id int primary key auto_increment,
	imei bigint not null unique,
	email varchar(255) not null

);


