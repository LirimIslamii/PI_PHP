<?php
	$servername = "localhost";
	$dBUsername = "root";
	$dBPassword = "";
	$dBName ="projekti";
	$conn = mysqli_connect($servername, $dBUsername, $dBPassword, $dBName);
	// Check connection
	if ($conn->connect_error) {
	    die("Connection failed: " . $conn->connect_error);
	}
?>