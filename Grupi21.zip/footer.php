	<footer>
			<div class="footer-top">
				<div class="container">
					<div class="row">
						<div class="col-md-3 col-sm-6 col-xs-12 segment-one md-mb-30 sm-mb-30">
							<h2>Contact Info</h2>
							<p>Email: lirim.islami252@gmail.com</p>
							<p>Phone: +38344243908</p>
							<p>Address: Viti</p>
							<p>Faculty: FIEK</p>
							
						</div>
						<div class="col-md-3 col-sm-6 col-xs-12 segment-two md-mb-30 sm-mb-30">
							<h2>Macbook</h2>
							<ul>
								<li><a href="https://www.macrumors.com/review/13-inch-macbook-pro-2020/">Pro 2020</a></li>
								<li><a href="https://www.theverge.com/2018/11/6/18064552/macbook-air-2018-review-retina-keyboard-apple-features-battery-price">Air 2018</a></li>
								<li><a href="https://everymac.com/systems/apple/macbook_pro/specs/macbook-pro-core-i7-2.4-15-early-2013-retina-display-specs.html">Early 2013</a></li>
								<li><a href="https://en.wikipedia.org/wiki/MacBook_(2006%E2%80%932012)">PowerBook 2011</a></li>
								<li><a href="https://dbrand.com/macbook-skins">Pro Scin 2019</a></li>
							</ul>
						</div>
						<div class="col-md-3 col-sm-6 col-xs-12 segment-three sm-mb-30">
							<h2>Follow us</h2>
							<p>Please follow us in our social media to keep more in contac with us</p>
							<a href="https://www.facebook.com/lirimislamii"><i class="fa fa-facebook"></i></a>	
							<a href="https://www.instagram.com/_rinormehmeti_"><i class="fa fa-instagram"></i></a>	
							<a href="https://www.twitter.com"><i class="fa fa-twitter"></i></a>	
							<a href="https://www.linkedin.com"><i class="fa fa-linkedin"></i></a>		
						</div>
						<div class="col-md-3 col-sm-6 col-xs-12 segment-four sm-mb-30">
							<h2>Youtube</h2>
							<p>Check Video proof of this webpage for unlocking on my channel</p>
							<a href="https://www.youtube.com/watch?v=AkjPZiZ2LX8&feature=youtu.be"><button>
								Redirect
							</button></a>
						
						</div> 
					</div>
				</div>
			</div>
			<p class="footer-bottom-text">All Right Reserved  &copy;PHP-2020</p>
		</footer>