<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<h3>NA KONTAKTONI</h3>
                    <form id="contact_form">
                    <label></label>
                    <input type="text" name="Username" id="usern" placeholder="Username">
                    <br>
                    <label></label>
                    <input type="email" name="Email" id="userna" placeholder="Email" />
                    <br>
                    <textarea name="message" rows="3" cols="21" id="tekst" placeholder="Message"></textarea>
                    <input type="submit" id="sub" value="Submit" />




<script>

$(document).ready(function(){

	$("#contact_form").submit(function(e) {

		e.preventDefault();

		$.ajax({
	    url: "https://formspree.io/xyykaobe", 
	    method: "POST",
	    data: {
	    	Emri: $("#usern").val(),
	    	Imela: $("#userna").val(),
	    	Mesazhi: $("#tekst").val()
	    },
	    dataType: "json"
		}).done(function(){
			$("#usern").val("");
			$("#userna").val("");
			$("#tekst").val("");
			alert("Success!");
		}).fail(function(){
			alert("Error!");
		});
	});

});