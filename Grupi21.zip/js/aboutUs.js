function UranLajqi(){
	document.getElementById("uran").style.display = "";
}
function LirimIslami(){
	document.getElementById("lirim").style.display = "";
}

function RinorMehmeti(){
	document.getElementById("rinor").style.display = "";
}

